CAT105TC - W4 lab character frames
==================================

Character: "Male person" from the Kenney "Toon Characters" pack (kenney.nl, CC0 / public domain).
You may use, modify and redistribute these frames freely (crediting Kenney is optional).

Files (all 96 x 128 px, feet on the BOTTOM edge):
  idle.png
  walk0.png ... walk7.png      (walk cycle, 8 frames, loop)
  run0.png  run1.png run2.png  (run cycle, 3 frames, loop)
  jump.png
  fall.png

Unity import settings:
  Texture Type ........ Sprite (2D and UI)
  Sprite Mode ......... Single
  Pixels Per Unit ..... 96
  Pivot ............... Bottom Center
  Mip Maps ............ off
  Alpha Is Transparency  on

Animation clips to build (Window > Animation):
  Idle  : idle                        8 fps, loop
  Walk  : walk0..walk7                12 fps, loop
  Run   : run0..run2                  14 fps, loop
  Jump  : jump                        8 fps, no loop
  Fall  : fall                        8 fps, no loop

Animator parameters: Speed (float 0..1), VerticalSpeed (float), IsGrounded (bool), Jump (trigger)
States: Idle / Walk / Run / Jump / Fall   (default Idle)

Drive it from a 2D controller with:
  animator.SetFloat("Speed", speed01);
  animator.SetFloat("VerticalSpeed", rb.velocity.y);
  animator.SetBool ("IsGrounded", grounded);
  animator.SetTrigger("Jump");     // when you apply the jump impulse
